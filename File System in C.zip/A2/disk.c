#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#include "disk.h"
int count_size=-1;


/* Invalid file descriptor */
#define INVALID_FD -1

/* Disk instance description */
struct disk {
	/* File descriptor */
	int fd;
	/* Block count */
	size_t bcount;
};

/* Currently open virtual disk (invalid by default) */
static struct disk disk = { .fd = INVALID_FD };

int block_disk_open(const char *diskname)
{
	int fd;
	struct stat st;
	
	/* Parameter checking */
	if (!diskname) {
		return -1;
	}

	if (disk.fd != INVALID_FD) {
		return -1;
	}

	if ((fd = open(diskname, O_RDWR | O_CREAT, 0777)) < 0) {
		return -1;
	}

	if (fstat(fd, &st)) {
		return -1;
	}

	disk.fd = fd;
	disk.bcount = st.st_size / BLOCK_SIZE;

	return 0;
}

int block_isempty(const char *diskname)

{	
	int count_size;
	struct stat st;
	fstat(disk.fd, &st);
	if (st.st_size==0){
		count_size=0;
	}
	else{
		count_size=1;
	}
	return count_size;
}

int block_disk_close(void)
{
	if (disk.fd == INVALID_FD) {
		return -1;
	}
	close(disk.fd);

	disk.fd = INVALID_FD;

	return 0;
}

void printDisk(const char *diskname)
{
	FILE *f;
	char s;
	f=fopen(diskname, "r");
	while((s=fgetc(f))!=EOF) {
      printf("%c",s);
   }
   fclose(f);
}

int block_write(const void *buf)
{
	if (disk.fd == INVALID_FD) {
		return -1;
	}
	
	if (lseek(disk.fd, 0, SEEK_SET) < 0) {
		return -1;
	}

	if (write(disk.fd, buf, 4194304) < 0) {
		return -1;
	}

	return 0;
}

int block_read(void *buf)
{
	if (disk.fd == INVALID_FD) {
		return -1;
	}


	if (lseek(disk.fd, 0, SEEK_SET) < 0) {
		return -1;
	}

	if (read(disk.fd, buf, 4194304) < 0) {
		return -1;
	}

	return 0;
}