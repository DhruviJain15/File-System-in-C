#ifndef _DISK_H
#define _DISK_H

#include <stddef.h>

#define DISK_SIZE 4194304
#define BLOCK_SIZE 1024

int block_disk_open(const char *diskname);

int block_disk_close(void);

int block_write(const void *buf);

int block_read(void *buf);

int block_isempty(const char *diskname);

#else
#error "Private header, can't be included from applications directly"
#endif
