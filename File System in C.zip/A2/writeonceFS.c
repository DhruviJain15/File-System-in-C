#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <errno.h>

#include "disk.h"

extern int errno;
typedef enum flag {WO_RDONLY = 1, WO_WRONLY = 2, WO_RDWR = 3}; 

struct superblock_t {
    char signature[4];
    int totalNumberOfBlocks;
    int numberOfDataBlocks;
    int numberOfInodes;
    int iNodeBlockIndex;
    int startOfDataBlocks;
    int iNodeBitMapIndex;
    int dataBitMapIndex;
    int fileNameBlockIndex;
    int unused[247];
};

struct iNodeBitMap_t {
    int bitMap[64];
	int  unused[192];
};


struct dataBitMap_t {
    char dataBits[512];
    char unused[512];
};

struct dataBlock_t {
    char dataBits[1022];
    short nextBlock;
};

struct fileName_t {
    char filename[16];
};

struct INode {
    char unused[8];
	uint32_t size;
    short permission;
    short direct;
};


struct file_descriptor_t {
    int   is_used;       
    int    file_index; 
    int openedMode;             
    uint32_t offset;  
	char   file_name[16];
};

struct superblock_t *superBlock;
struct iNodeBitMap_t *iNodeDataBitMap;
struct dataBitMap_t *dataBitMap_tBM;
struct INode *iNode[64];
struct file_descriptor_t fd_table[64];
struct fileName_t *fileName_dt[64];
struct dataBlock_t *dataBlock;
char *virtualDiskBegin;

int wo_mount(char *diskname, void *memoryAddress)
{
    if(block_disk_open(diskname) < 0){
        errno = 1;
        printf("Error description is : %s\n",strerror(errno));
        return -1;
    }
    virtualDiskBegin = memoryAddress;
    if(block_isempty(diskname) == 0){
        //Initialize Superblock
        superBlock = memoryAddress;
        superBlock->signature[0] = 'O';
        superBlock->signature[1] = 'S';
        superBlock->signature[2] = 'A';
        superBlock->signature[3] = '3';
        
        superBlock->totalNumberOfBlocks = 4096;
        superBlock->numberOfDataBlocks = 4091;
        superBlock->numberOfInodes = 64;
        superBlock->iNodeBlockIndex = 3;
        superBlock->startOfDataBlocks = 5;
        superBlock->iNodeBitMapIndex = 1;
        superBlock->dataBitMapIndex = 2;
        superBlock->fileNameBlockIndex = 4;
        memset(superBlock->unused, 0, 988);

        //Initialize Inode Bitmap
        iNodeDataBitMap = memoryAddress+1024;
        int bufiNodeBM[64];
        int bufunusediNodeBM[192];
        memset(bufiNodeBM, 0, 256);
        memset(bufunusediNodeBM, 0, 768);
        memcpy(&iNodeDataBitMap->bitMap, bufiNodeBM, 256);
        memcpy(&iNodeDataBitMap->unused, bufunusediNodeBM, 768);

        //Initialize Data Bitmap Initialize
        dataBitMap_tBM = memoryAddress + 1024*2;
        char bufForDataBM[512];
        memset(bufForDataBM, 0, 512);
        bufForDataBM[0]=31;
        memcpy(&dataBitMap_tBM->dataBits, bufForDataBM, 512);
        bufForDataBM[0]=0;
        memcpy(&dataBitMap_tBM->unused, bufForDataBM, 512);

        //Initializing iNode
        for(int i=0;i<64;i++){
            iNode[i] = memoryAddress + 1024*3 + i*16;
            char bufForiNode[8];
            memset(bufForiNode, '0', 8);
            memcpy(iNode[i]->unused, bufForiNode, 8);
            iNode[i]->permission = 3;
			iNode[i]->size = 0;
            iNode[i]->direct=0; 
        }

        //Initializing iNode FileNames
        for(int i=0;i<64;i++){
            fileName_dt[i] = memoryAddress + 1024*4 + i*16;
            char bufForiNodefileName[16];
            memset(bufForiNodefileName, '\0', 16);
            memcpy(fileName_dt[i]->filename, bufForiNodefileName, 16);
        }
    }

    else
    {
        if(block_read((void*)memoryAddress)<0){
            errno = 1;
            printf("Error description is : %s\n",strerror(errno));
            return -1;
        }

        //Validating if opened file is valid
        superBlock = memoryAddress;
        if(strcmp(superBlock->signature, "OSA3") != 0){
            errno = 117;
            printf("Error description is : %s\n",strerror(errno));
            return -1;
        }
        if(superBlock->totalNumberOfBlocks != 4096){
            errno = 117;
            printf("Error description is : %s\n",strerror(errno));
            return -1;
        }

        if(superBlock->numberOfDataBlocks != 4091){
            errno = 117;
            printf("Error description is : %s\n",strerror(errno));
            return -1;
        }

        if(superBlock->numberOfInodes != 64){
            errno = 117;
            printf("Error description is : %s\n",strerror(errno));
            return -1;
        }

        if(superBlock->iNodeBlockIndex != 3){
            errno = 117;
            printf("Error description is : %s\n",strerror(errno));
            return -1;
        }

        if(superBlock->startOfDataBlocks != 5){
            errno = 117;
            printf("Error description is : %s\n",strerror(errno));
            return -1;
        }

        if(superBlock->iNodeBitMapIndex != 1){
            errno = 117;
            printf("Error description is : %s\n",strerror(errno));
            return -1;
        }

        if(superBlock->dataBitMapIndex != 2){
            errno = 117;
            printf("Error description is : %s\n",strerror(errno));
            return -1;
        }

        if(superBlock->fileNameBlockIndex != 4){
            errno = 117;
            printf("Error description is : %s\n",strerror(errno));
            return -1;
        }

    }
	for(int i = 0; i < 64; i++) {
		fd_table[i].is_used = 0;
        fd_table[i].is_used = 0;
		fd_table[i].file_index = -1;
        memset(fd_table[i].file_name, '0', 16);
        fd_table[i].openedMode = 0;
	}
    return 0;
}

int wo_unmount(void *memoryAddress)
{
    if(block_write((void*)memoryAddress) < 0) {
        errno = 1;
        printf("Error description is : %s\n",strerror(errno));
        return -1;
    }
	for(int i = 0; i < 64; i++) {
		fd_table[i].offset = 0;
		fd_table[i].is_used = 0;
        fd_table[i].openedMode = 0;
		fd_table[i].file_index = -1;
        memset(fd_table[i].file_name, '0', 16);
    }
    
    block_disk_close();
    return 0;
}

int wo_open(char* filename, int flags)
{
    struct INode *iNodeForOpen;
    struct fileName_t *fileName_ForOpen;
	int fileFoundToOpen = 0;
	for(int i=0;i<64;i++){
		iNodeForOpen = virtualDiskBegin + 1024*3 + i*16;
        fileName_ForOpen = virtualDiskBegin + 1024*4 + i*16;
		if(strcmp(fileName_ForOpen->filename,filename) == 0){
            if(iNodeForOpen->permission < 1 || iNodeForOpen->permission>3){
                errno = 13;
                printf("Error description is : %s\n",strerror(errno));
        		return -1;
            }
            for(int i=0;i<64;i++){
                //TODO:Checking if file is already open. Should return error? return -1?
		        if(fd_table[i].is_used == 1){
			        if(strcmp(fd_table[i].file_name,filename) == 0){
                        errno = 1;
                        printf("Error description is : %s\n",strerror(errno));
        		        return -1;
                    }
		        }
	        }
			int fd = locateAvailableFD();
			if (fd == -1){
				errno = 23;
                printf("Error description is : %s\n",strerror(errno));
        		return -1;
   			}
			fd_table[fd].is_used=1;
			fd_table[fd].file_index = i;
			fd_table[fd].offset = 0;
            fd_table[i].openedMode = flags;
			strcpy(fd_table[fd].file_name, fileName_ForOpen->filename);
			fileFoundToOpen = 1;
			return fd;
		}
	}
        
	if(fileFoundToOpen == 0){
		errno = 9;
        printf("Error description is : %s\n",strerror(errno));
        return -1;
	}
    return -1;
}

int wo_create(char* filename, int flags)
{
    struct INode *iNodeForOpen;
    struct fileName_t *fileName_ForOpen;
    int noSpaceLeft = 0;
	for(int i=0;i<64;i++){
		iNodeForOpen = virtualDiskBegin + 1024*3 + i*16;
        fileName_ForOpen = virtualDiskBegin + 1024*4 + i*16;
		if(strcmp(fileName_ForOpen->filename,filename) == 0){
			errno = 17;
            printf("Error description is : %s\n",strerror(errno));
        	return -1;
		}
	}
    iNodeDataBitMap = virtualDiskBegin + 1*1024;
	for(int i=0;i<64;i++){
		if(iNodeDataBitMap->bitMap[i] == 0){
            iNodeForOpen = virtualDiskBegin + 1024*3 + i*16;
            fileName_ForOpen = virtualDiskBegin + 1024*4 + i*16;
            strcpy(fileName_ForOpen->filename, filename);
            iNodeForOpen->permission = 3;
			iNodeForOpen->size = 0;
            iNodeForOpen->direct=0;
            char bufForiNode[8];
            memset(bufForiNode, '0', 8);
            memcpy(iNodeForOpen->unused, bufForiNode, 8);

            int fd = locateAvailableFD();
            if (fd == -1){
				errno = 23;
                printf("Error description is : %s\n",strerror(errno));
        		return -1;
   			}
			fd_table[fd].is_used=1;
			fd_table[fd].file_index = i;
			fd_table[fd].offset = 0;
            fd_table[i].openedMode = flags;
			strcpy(fd_table[fd].file_name, fileName_ForOpen->filename);

            iNodeDataBitMap->bitMap[i] = 1;
            noSpaceLeft = 1;
            return fd;
        }
            
	}
    if(noSpaceLeft == 0){
        errno = 23;
        printf("Error description is : %s\n",strerror(errno));
        return -1;
    }
    return -1;
}

int locateAvailableFD()
{
	for(int i=0;i<64;i++){
		if(fd_table[i].is_used == 0){
			return i;
		}
	}
	return -1;
}			

int wo_close(int fd)
{
    if(fd>=64 || fd<0 || fd_table[fd].is_used == 0){
        errno = 9;
        printf("Error description is : %s\n",strerror(errno));
        return -1;
    }
    struct file_descriptor_t *fd_d = &fd_table[fd];
    int iNodeIndexOfFile = fd_d->file_index;
    
    if(iNodeIndexOfFile == -1) { 
        errno = 9;
        printf("Error description is : %s\n",strerror(errno));
        return -1;
    } 

    fd_d->is_used = 0;
    fd_d->file_index=-1;
    fd_d->offset=0;
    fd_d->openedMode = 0;
    
    memset(fd_d->file_name, '0', 16);
	return 0;
}

int wo_write(int fd, void *bufferAddress, int bytes)
{
    if(fd>=64 || fd<0){
        errno = 9;
        printf("Error description is : %s\n",strerror(errno));
        return -1;
    }
    if(fd_table[fd].is_used == 0){
        errno = 9;
        printf("Error description is : %s\n",strerror(errno));
        return -1;
    }
    if(fd_table[fd].openedMode == 2 || fd_table[fd].openedMode == 3){
        struct INode *iNodeForWrite;
        if(bytes <= 0){
            errno = 22;
            printf("Error description is : %s\n",strerror(errno));
            return 0;
        }
        
        int iNodeIndex = fd_table[fd].file_index;
        iNodeForWrite = virtualDiskBegin + 1024*3 + iNodeIndex*16;
        struct dataBitMap_t *dataBMForWrite;
        dataBMForWrite = virtualDiskBegin + 1024*2;
        uint32_t totalBytesWriten = 0;
        if(iNodeForWrite->size == 0){
            int numOfBlocks;
            if(bytes%1022 == 0){
                numOfBlocks = bytes/1022;
            }else{
                numOfBlocks = bytes/1022 + 1;
            }
            short freeBlock[numOfBlocks];
            int freeCount = 0;
            for(int i=0;i<4096;i++){
                int bitValue = get_bit(dataBMForWrite->dataBits, i);
                
                if(freeCount == numOfBlocks){
                    break;
                }
                if(bitValue == 0){
                    set_bit(dataBMForWrite->dataBits, i);
                    freeBlock[freeCount] = i;
                    freeCount = freeCount + 1;
                }
                
            }
            if(freeCount < numOfBlocks){
                bytes = 1022 * freeCount;
                numOfBlocks = freeCount;
            }
            for(int i=0;i<numOfBlocks;i++){
                dataBlock = virtualDiskBegin + 1024*freeBlock[i];
                if(i==0){
                    iNodeForWrite->direct=freeBlock[i];
                }
                if(bytes > 1022){
                    memcpy(&dataBlock->dataBits, (char*)bufferAddress, 1022);
                    if(i==numOfBlocks-1){
                        dataBlock->nextBlock = 0;
                    }else{
                        dataBlock->nextBlock = freeBlock[i+1];
                    }
                    bufferAddress = bufferAddress + 1022;
                    bytes = bytes - 1022;
                    totalBytesWriten = totalBytesWriten + 1022;
                }else{
                    memcpy(&dataBlock->dataBits, (char*)bufferAddress, bytes);
                    dataBlock->nextBlock = 0;
                    totalBytesWriten = totalBytesWriten + bytes;
                }
            }
        }else{
            int noOfFreeBytesInCurrBlock;
            if(iNodeForWrite->size%1022 == 0){
                noOfFreeBytesInCurrBlock = 0;
            }else{
                noOfFreeBytesInCurrBlock = 1022 - iNodeForWrite->size%1022;
            }
            int remainingBytes = 0;
            if(bytes > noOfFreeBytesInCurrBlock){
                remainingBytes = bytes - noOfFreeBytesInCurrBlock;
            }else{
                remainingBytes = 0;
            }
            int numOfBlocks;
            if(remainingBytes%1022 == 0){
                numOfBlocks = remainingBytes/1022;
            }else{
                numOfBlocks = remainingBytes/1022 + 1;
            }
            if(noOfFreeBytesInCurrBlock != 0){
                int currBlock = iNodeForWrite->size/1022;
                int blockNumberOfCurrentBlock;
                if(currBlock == 0){
                    dataBlock = virtualDiskBegin + 1024*iNodeForWrite->direct;
                }else{
                    for(int i=0;i<=currBlock;i++){
                        if(i==0){
                            dataBlock = virtualDiskBegin + 1024*iNodeForWrite->direct;
                        }else{
                            short nextBlock = dataBlock->nextBlock;
                            dataBlock = virtualDiskBegin + 1024*nextBlock;
                        }
                    }
                }
                dataBlock->nextBlock = 0;
                short temp = iNodeForWrite->size%1022;
                struct dataBlock_t *tempDataBlock = (char*)dataBlock + temp;
                if(bytes > noOfFreeBytesInCurrBlock){
                    memcpy(&tempDataBlock->dataBits, (char*)bufferAddress, noOfFreeBytesInCurrBlock);
                    totalBytesWriten = totalBytesWriten + noOfFreeBytesInCurrBlock;
                    bufferAddress = bufferAddress + noOfFreeBytesInCurrBlock;
                }else{
                    memcpy(&tempDataBlock->dataBits, (char*)bufferAddress, bytes);
                    totalBytesWriten = totalBytesWriten + bytes;
                    bufferAddress = bufferAddress + bytes;
                }
                
            }else{
                dataBlock = virtualDiskBegin + 1024*iNodeForWrite->direct;
                while(dataBlock->nextBlock != 0){
                    short nextBlock = dataBlock->nextBlock;
                    dataBlock = virtualDiskBegin + 1024*nextBlock;
                }
            }
            if(numOfBlocks > 0){
                int freeBlock[numOfBlocks];
                int freeCount = 0;
                for(int i=0;i<4096;i++){
                    int bitValue = get_bit(dataBMForWrite->dataBits, i);
                    
                    if(freeCount == numOfBlocks){
                        break;
                    }
                    if(bitValue == 0){
                        set_bit(dataBMForWrite->dataBits, i);
                        freeBlock[freeCount] = i;
                        freeCount = freeCount + 1;
                    }
                    
                }
                if(freeCount < numOfBlocks){
                    remainingBytes = 1022 * freeCount;
                    numOfBlocks = freeCount;
                }
                for(int i=0;i<numOfBlocks;i++){
                    if(i==0){
                        dataBlock->nextBlock = freeBlock[i];
                    }
                    dataBlock = virtualDiskBegin + 1024*freeBlock[i];
                    if(i==numOfBlocks-1){
                        dataBlock->nextBlock = 0;
                    }else{
                        dataBlock->nextBlock = freeBlock[i+1];
                    }
                    if(remainingBytes > 1022){
                        memcpy(&dataBlock->dataBits, (char*)bufferAddress, 1022);
                        bufferAddress = bufferAddress + 1022;
                        remainingBytes = remainingBytes - 1022;
                        totalBytesWriten = totalBytesWriten + 1022;
                    }else{
                        memcpy(&dataBlock->dataBits, (char*)bufferAddress, remainingBytes);
                        totalBytesWriten = totalBytesWriten + remainingBytes;
                    }
                }
            }
        }
        iNodeForWrite->size = iNodeForWrite->size + totalBytesWriten;
        return totalBytesWriten;
    }else{
        errno = 13;
        printf("Error description is : %s\n",strerror(errno));
        return -1;
    }
}

int wo_read( int fd,  void* buffer, int bytes)
{
    if(fd>=64 || fd<0){
        errno = 9;
        printf("Error description is : %s\n",strerror(errno));
        return -1;
    }
    if(fd_table[fd].is_used == 0) {
		errno = 9;
        printf("Error description is : %s\n",strerror(errno));
        return -1;
    } 
    if(fd_table[fd].openedMode == 1 || fd_table[fd].openedMode == 3){
        if (bytes <= 0) {
            errno = 22;
            printf("Error description is : %s\n",strerror(errno));
            return -1;
        } 
        
        struct dataBlock_t *dataBlockforelse;
        char *file_name = fd_table[fd].file_name;
        int file_index = fd_table[fd].file_index;
        
        size_t offset = fd_table[fd].offset;
        struct INode *ino=virtualDiskBegin+1024*3+file_index*16;
        if (ino->size== 0) {
            errno = 1;
            printf("Error description is : %s\n",strerror(errno));
            return -1;
        }
        else if(offset>=ino->size){
            errno = 1;
            printf("Error description is : %s\n",strerror(errno));
            return -1;
        }
        
        int read_rem=0;
        if (offset + bytes > ino->size) {
            read_rem = abs(ino->size - offset);
        }
        else read_rem = bytes;
        char *read_buf = (char *)buffer;
        size_t num_blocks;
        if(read_rem % BLOCK_SIZE == 0){
            num_blocks = read_rem/BLOCK_SIZE;
        }
        else{
            num_blocks = (read_rem/BLOCK_SIZE) +2;
        }
        if(offset!=0 && offset%BLOCK_SIZE!=0 && offset%1022<bytes)
            num_blocks=num_blocks+1;
        int cur_block = offset / BLOCK_SIZE;
        int location= offset % BLOCK_SIZE;
        char new_buff[BLOCK_SIZE];
        
        int left_shift = 0;
        int total_bytes_read = 0;
        if (cur_block!=0)
        {
            for(int i=0;i<(cur_block+1);i++){
                if (i==0){
                dataBlockforelse = virtualDiskBegin + 1024*ino->direct;
                }
                else{
                short nextBlock = dataBlockforelse->nextBlock;
                dataBlockforelse = virtualDiskBegin + 1024*nextBlock;
                }
            }
            for (int i = 0; i < num_blocks; i++) {
                if (i==0)
                {
                dataBlock=dataBlockforelse;
                }
                else 
                {
                short nextBlock = dataBlock->nextBlock;
                dataBlock = virtualDiskBegin + 1024*nextBlock;
        
                }
                if (location+ read_rem > BLOCK_SIZE) 
                {
                left_shift = BLOCK_SIZE - location;
                } else {
                left_shift = read_rem;
                }
            

                
                memcpy(read_buf, (dataBlock->dataBits)+location, left_shift );
                offset+=left_shift;
                total_bytes_read += left_shift;
                read_buf += left_shift;
            
            
                location= 0;
                read_rem -= left_shift;   
            } 
        }
        
        else
        {

            for (int i = 0; i < num_blocks; i++) {
                if (cur_block==0){
                    dataBlock = virtualDiskBegin + 1024*ino->direct;
                }
                else{
                short nextBlock = dataBlock->nextBlock;
                dataBlock = virtualDiskBegin + 1024*nextBlock;
                }
            

            
                if (location+ read_rem > BLOCK_SIZE) {
                    left_shift = BLOCK_SIZE - location;
                
                } else {
                left_shift = read_rem;
                }
            

                
            memcpy(read_buf, (dataBlock->dataBits)+location, left_shift );
            offset+=left_shift;
            total_bytes_read += left_shift;
            read_buf += left_shift;
            
            
            location= 0;
            read_rem -= left_shift;
            cur_block+=1;
            }
        }

        fd_table[fd].offset += total_bytes_read;
        return total_bytes_read;
    }else{
        errno = 13;
        printf("Error description is : %s\n",strerror(errno));
        return -1;
    }	
    
	
}
    
void prettyPrintiNode()
{
    struct fileName_t *fileName_ForLocateFile ;
    for(int i=0;i<64;i++){
        iNode[i] = virtualDiskBegin + 1024*3 + i*16;
        fileName_ForLocateFile = virtualDiskBegin + 1024*4 + i*16;
        printf("iNode Name %s, Permission %d, Size %lu, Data block 1 %d\n", fileName_ForLocateFile->filename,iNode[i]->permission,iNode[i]->size, iNode[i]->direct);
    }
}
void prettyprintfd()
{
    for(int i=0;i<64;i++){
		if(fd_table[i].is_used == 1){
			printf("File Name %s, size %d, index %d, isUsed %d\n",fd_table[i].file_name, fd_table[i].offset, fd_table[i].file_index, fd_table[i].is_used);
		}
	}
}

void set_bit(char* dataBits, int index)
{
    int arrayIndex = index/8;
    int bitIndex = index%8;

    int bitwiseOperand = 1<<bitIndex;
    dataBits[arrayIndex] = dataBits[arrayIndex] | bitwiseOperand;
}

int get_bit(char* dataBits, int index) 
{
    int arrayIndex = index/8;
    int bitIndex = index%8;

    int bitwiseOperand = 1<<bitIndex;
    if ((dataBits[arrayIndex] & bitwiseOperand) > 0) return 1;
    return 0;
}

void calculateNoofBlocksInFile(int fd)
{
    struct INode *iNodeForWrite;
    
    int iNodeIndex = fd_table[fd].file_index;
    iNodeForWrite = virtualDiskBegin + 1024*3 + iNodeIndex*16;
    struct dataBlock_t *dataBlock_tNoOf = virtualDiskBegin + 1024*iNodeForWrite->direct;

    int count = 1;
    while(dataBlock_tNoOf->nextBlock != 0){
        dataBlock_tNoOf = virtualDiskBegin + 1024*dataBlock_tNoOf->nextBlock;
        count=count+1;
    }
    printf("Number of data blocks used by file with fd %d is %d\n",fd, count);
}
